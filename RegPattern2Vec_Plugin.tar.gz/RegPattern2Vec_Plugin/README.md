## RegPattern2Vec - Link Prediction in Knowledge Graph

### A Plugin Implementation for Neo4j